export const 
  GOOGLE_API_KEY = 'AIzaSyByPwd-6SFcXjLuDvKTNOrLt8xZvjuzafg',
  CALENDAR_ID = 'c_gfdoqnaehffpt274qe2fglqgqk@group.calendar.google.com';