import React from 'react';
import ReactDOM from 'react-dom'
import './index.css';
import App from './App';


const root = ReactDOM.render(<App/>,document.getElementById('root'),function(){
  let loader = document.getElementById('app-loader');
  loader.parentNode.removeChild(loader);
});

